// Code by Raj
const mongoose = require("mongoose");

const AttendanceSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
    },
    biometricId: {
        type: String,
    },
    loginOrLogout: {
        type: String,
        enum: ["Login", "Logout"],
        required: true,
    },
    attendanceType: {
        type: String,
        enum: ["System", "Manual"],
        required: true,
    },
    dateTime: {
        type: Date,
        default: Date.now,
    },
    duration: {
        type: String,
    },
    deleted: {
        type: Boolean,
        default: false,
    },
});

module.exports = mongoose.model("Attendance", AttendanceSchema);
// Code by Raj end

// const mongoose = require('mongoose');

// const AttendanceSchema = new mongoose.Schema({
//     user: {
//         type: mongoose.Schema.ObjectId,
//         ref: 'User'
//     },
//     student: {
//         type: mongoose.Schema.ObjectId,
//         ref: 'Student'
//     },
//     name: {
//         type: String,
//         required: true
//     },
//     designation: {
//         type: String,
//         enum: ['Admin', 'Manager', 'Teacher', 'Student', 'Other'],
//         required: true
//     },
//     loginOrLogout: {
//         type: String,
//         enum: ['Login', 'Logout'],
//         required: true
//     },
//     attendanceType: {
//         type: String,
//         enum: ['System', 'Manual'],
//         required: true
//     },
//     dateTime: {
//         type: Date,
//         required: [true, 'Please add attendance date and time']
//     },
//     currentJobTime: {
//         type: String,
//         required: [true, 'Please add job time']
//     },
//     branch: {
//         type: String,
//         required: [true, 'Branch name is required to create new attendance']
//     },
//     createdAt: {
//         type: Date,
//         default: Date.now
//     },
//     updatedAt: Date,
//     deleted: {
//         type: Boolean,
//         default: false
//     }
// });


// module.exports = mongoose.model('Attendance', AttendanceSchema);