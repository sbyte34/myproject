const mongoose = require('mongoose');

const ManagerSchema = new mongoose.Schema({
    dob: {
        type: Date,
        required: [true, 'Please add a manager Date of Birth']
    },
    phone: {
        type: Number,
        required: [true, 'Please add a manager phone']
    },
    address: {
        type: String,
        required: [true, 'Please add a manager address']
    },
    educationalQualification: {
        type: String
    },
    joiningDate: {
        type: Date,
        required: [true, 'Please add a manager Joining Date']
    },
    jobTime: {
        type: String,
        required: [true, 'Please add a manager Job Time']
    },
    user: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to created new manager'] // Because every manager needs to have a login credentials
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Manager', ManagerSchema);