const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema({
    // Personal Details
    firstName: {
        type: String,
        trim: true,
        required: [true, 'Please add a student first name']
    },
    middleName: {
        type: String,
        trim: true,
        required: [true, 'Please add a student middle name']
    },
    lastName: {
        type: String,
        trim: true,
        required: [true, 'Please add a student last name']
    },
    dob: {
        type: Date,
        required: [true, 'Please add a student Date of Birth']
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Other'],
        required: [true, 'Please add a student gender']
    },
    religion: {
        type: String,
        required: [true, 'Please add a student religion']
    },
    caste: {
        type: String,
        required: [true, 'Please add a student caste']
    },
    aadhaarNo: {
        type: Number,
        maxlength: [12, 'Aadhaar number can not be more than 12 digits']
    },
    // Family Details
    motherName: {
        type: String,
        trim: true,
        required: [true, "Please add a student mother's name"]
    },
    fatherOccupation: {
        type: String,
        required: [true, "Please add a student father's occupation"]
    },
    motherTongue: {
        type: String,
        required: [true, 'Please add a student mother tongue']
    },
    // Contact Details 
    address: {
        type: String,
        required: [true, 'Please add a student address']
    },
    parentPhone: {
        type: Number,
        // required: [true, 'Please add a student parent phone']
    },
    phone1: {
        type: Number,
        required: [true, 'Please add a student phone 1']
    },
    phone2: {
        type: Number,
        // required: [true, 'Please add a student phone 2']
    },
    email: {
        type: String,
        required: [true, 'Please add a student email'],
        match: [
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            'Please add a valid email'
        ]
    },
    // Educational Details
    qualification: {
        type: String,
        required: [true, 'Please add a student qualification']
    },
    schoolOrCollegeName: {
        type: String,
        required: [true, 'Please add a student school or college name']
    },
    classOrTuitionName: {
        type: String,
        required: [true, 'Please add a student class or tuition name']
    },
    // Other Details
    category: {
        type: String,
        enum: ['Student', 'Service', 'HomeMaker'],
        required: [true, 'Please add a student category']
    },
    reference: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Reference', // Reference to another model to connect with
    },
    facebook: String,
    instagram: String,
    youtube: String,
    twitter: String,
    linkedin: String,
    // Organization Details
    enquiry: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Enquiry', // Reference to another model to connect with
    },
    branch: {
        type: String,
        required: [true, 'Branch id is required to create new student'] // Because every student needs to have a login credentials
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new student'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Student', StudentSchema);