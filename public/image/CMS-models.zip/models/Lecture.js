const mongoose = require('mongoose');

const LectureSchema = new mongoose.Schema({
    teacher: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'Teacher id is required to create new lecture']
    },
    course: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Course', // Reference to another model to connect with
        required: [true, 'Course id is required to create new lecture']
    },
    student: {
        type: String, // This is special type of mongoose i.e. the _id of any document
        // ref: 'Student', // Reference to another model to connect with
        required: [true, 'Student id is required to create new lecture']
    },
    dateTime: {
        type: Date,
        required: [true, 'Please add a lecture date and time']
    },
    topicsCovered: {
        type: String,
        required: [true, 'Please add a lecture topics']
    },
    lectureOrExam: {
        type: String,
        enum: ['Lecture', 'Exam'],
        default: false
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new lecture'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    },
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new lecture']
    }
});


module.exports = mongoose.model('Lecture', LectureSchema);