const mongoose = require('mongoose');

const WhatsapplogSchema = new mongoose.Schema({
    
    from: {
        type: String,
        require: true
    },
    to: {
        type: String,
        require: true
    },
    body: {
        type: String,
        require: true
    },
    numSegments: {
        type: Number,
        require: true
    },
    direction: {
        type: String,
        require: true
    },
    sid: {
        type: String,
        require: true
    },
    price: { type: Number },
    errorMessage: { type: String },
    numMedia: { type: Number },
    errorCode: { type: Number },
    priceUnit: { type: String },
    user: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    deleted: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('Whatsapplog', WhatsapplogSchema);