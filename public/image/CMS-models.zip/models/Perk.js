const mongoose = require('mongoose');

const PerkSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new perk']
    },
    points: {
        type: Number,
        min: 1,
        max: 10,
        required: [true, 'Please add a perk points between 1 and 10']
    },
    comment: {
        type: String,
        required: [true, 'Please add a perk comment'],
        enum: ['Inferior', 'Below Average', 'Mediocre', 'Average', 'Great', 'Above Average', 'Splendid', 'Excellent', 'Exceptional', 'Remarkable', 'Sets a new standard of performance']
    },
    // rewardFromDate: {
    //     type: Date,
    //     required: [true, 'Please add a perk from date']
    // },
    // rewardToDate: {
    //     type: Date,
    //     required: [true, 'Please add a perk to date']
    // },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new perk'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    },
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new perk']
    }
});


module.exports = mongoose.model('Perk', PerkSchema);