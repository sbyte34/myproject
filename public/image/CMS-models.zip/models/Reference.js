const mongoose = require('mongoose');

const ReferenceSchema = new mongoose.Schema({
    // Reference 1
    ref1Name: String,
    ref1Phone: Number,
    ref1Category: {
        type: String
    },
    ref1Area: String,
    // Reference 2
    ref2Name: String,
    ref2Phone: Number,
    ref2Category: {
        type: String
    },
    ref2Area: String,
    // Reference 3
    ref3Name: String,
    ref3Phone: Number,
    ref3Category: {
        type: String
    },
    ref3Area: String,
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new reference'] // Because every student needs to have a login credentials
    },
    student: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Student', // Reference to another model to connect with
        required: [true, 'Student id is required to create new reference'] // Because every course needs to have a user
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new reference'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Reference', ReferenceSchema);